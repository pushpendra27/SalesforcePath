import { LightningElement, track } from 'lwc';
import fetchContactFieldSetData from '@salesforce/apex/ContactFieldset.fetchContactFieldSetData';
import getFieldSet from '@salesforce/apex/ContactFieldset.getFieldSet';
import getCandidateList from '@salesforce/apex/ContactFieldset.getCandidateList';

export default class ContactFieldset extends LightningElement {
    @track data;
    @track candidate;
    @track columns;
    @track error;
    @track candidateId = ''; // Placeholder for Candidate ID

    handleCandidateIdChange(event) {
        this.candidateId = event.target.value; // Update candidateId from input
    }
/*
    handleSearch() {
        if (this.candidateId) {
            fetchContactFieldSetData({ candidateId: this.candidateId })
                .then((result) => {
                    this.data = result;
                    this.fetchCandidateData();
                    this.error = undefined;
                })
                .catch((error) => {
                    this.error = error;
                    this.data = undefined;
                });
        } else {
            this.error = 'Please enter a Candidate ID.';
            this.data = undefined;
            
        }
    }



    fetchCandidateData() {
        getCandidate({ candidateId: this.candidateId })
                .then((candidateResult) => {
                    this.CandidateData = candidateResult;
                    this.error = undefined;
                })
                .catch((error) => {
                    this.error = error;
                    this.data = undefined;
                });
    }


    handleSearch() {
    if (this.candidateId) {
        fetchContactFieldSetData({ candidateId: this.candidateId })
            .then((result) => {
                this.data = result;
                return getCandidateList({ candidateId: this.candidateId });
            })
            .then((candidateResult) => {
                this.candidate = candidateResult;
                console.log('CandidateData:', candidateResult); 
                this.error = undefined;
            })
            .catch((error) => {
                this.error = error;
                this.data = undefined;
                this.candidate = undefined;
            });
    } else {
        this.error = 'Please enter a Candidate ID.';
        this.data = undefined;
        this.candidate = undefined;
    }
}

*/

handleSearch() {
    if (!this.candidateId) {
        this.error = 'Please enter a Candidate ID.';
        this.data = undefined;
        this.candidate = undefined;
        return;
    }

    // Fetch both data sets in parallel and handle results
    Promise.all([
        fetchContactFieldSetData({ candidateId: this.candidateId }),
        getCandidateList({ candidateId: this.candidateId })
    ])
    .then(([interviewData, candidateResult]) => {
        console.log('Interview Data:', interviewData);
        console.log('Candidate Data:', candidateResult); // For debugging purposes

        // Check if candidate data exists
        if (!candidateResult || Object.keys(candidateResult).length === 0) {
            this.error = 'Candidate details not found.';
            this.candidate = undefined;
        } else {
            this.candidate = candidateResult;
            console.log('Candidate Res:'+JSON.stringify(this.candidate));
            this.error = undefined;
        }

        // Assign fetched interview data
        this.data = interviewData;
    })
    .catch((error) => {
        this.error = error?.body?.message || 'Failed to fetch data.';
        this.data = undefined;
        this.candidate = undefined;
    });
}



    connectedCallback() {
        getFieldSet({ sObjectName: 'Interview__c', fieldSetName: 'CandIntervirewFieldset' })
            .then((result) => {
                let cols = [];
                JSON.parse(result).forEach((currentItem) => {
                    cols.push({ label: currentItem.label, fieldName: currentItem.name });
                });
                this.columns = cols;
                this.error = undefined;
            })
            .catch((error) => {
                this.error = error;
                this.columns = undefined;
            });
    }

    get isColumnsDataAvailable() {
        return this.data && this.columns;
    }
}